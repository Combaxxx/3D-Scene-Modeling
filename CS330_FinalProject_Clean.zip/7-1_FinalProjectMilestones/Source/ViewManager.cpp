///////////////////////////////////////////////////////////////////////////////
// viewmanager.cpp
// ============
// Manage the viewing of 3D objects within the viewport, including the camera,
// keyboard movement, mouse movement, movement speed, and projection modes.
//
// AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
// Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM math header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

// Standard library used to limit the camera speed
#include <algorithm>

// Declaration of global variables and constants
namespace
{
	// Default window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;

	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// Camera used for viewing and interacting with the 3D scene
	Camera* g_pCamera = nullptr;

	// Variables used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// Time between the current frame and previous frame
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;

	// False uses perspective projection.
	// True uses orthographic projection.
	bool bOrthographicProjection = false;

	// These variables prevent projection mode from repeatedly
	// changing while a key is held down.
	bool gPKeyPressed = false;
	bool gOKeyPressed = false;

	// Camera movement speed changed by the mouse scroll wheel
	float gCameraSpeed = 5.0f;
}

/***********************************************************
 * ViewManager()
 *
 * Constructor for the class.
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager* pShaderManager)
{
	// Initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;

	g_pCamera = new Camera();

	// Default camera view parameters
	g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
	g_pCamera->Front = glm::vec3(0.0f, -0.5f, -2.0f);
	g_pCamera->Up = glm::vec3(0.0f, 1.0f, 0.0f);
	g_pCamera->Zoom = 80.0f;
	g_pCamera->MovementSpeed = gCameraSpeed;
}

/***********************************************************
 * ~ViewManager()
 *
 * Destructor for the class.
 ***********************************************************/
ViewManager::~ViewManager()
{
	// Free allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;

	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 * CreateDisplayWindow()
 *
 * Creates the main OpenGL display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(
	const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// Create the OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL,
		NULL);

	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();

		return NULL;
	}

	glfwMakeContextCurrent(window);

	// Capture the mouse cursor inside the application window
	glfwSetInputMode(
		window,
		GLFW_CURSOR,
		GLFW_CURSOR_DISABLED);

	// Register the mouse-position callback
	glfwSetCursorPosCallback(
		window,
		&ViewManager::Mouse_Position_Callback);

	// Register the mouse-scroll callback
	glfwSetScrollCallback(
		window,
		&ViewManager::Mouse_Scroll_Callback);

	// Enable blending for transparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(
		GL_SRC_ALPHA,
		GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	return window;
}

/***********************************************************
 * Mouse_Position_Callback()
 *
 * Called automatically whenever the mouse moves inside the
 * active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(
	GLFWwindow* window,
	double xMousePos,
	double yMousePos)
{
	// Record the first mouse location so the camera does not
	// suddenly jump when the program begins.
	if (gFirstMouse)
	{
		gLastX = static_cast<float>(xMousePos);
		gLastY = static_cast<float>(yMousePos);
		gFirstMouse = false;
	}

	// Calculate mouse movement offsets
	float xOffset =
		static_cast<float>(xMousePos) - gLastX;

	float yOffset =
		gLastY - static_cast<float>(yMousePos);

	// Store the current mouse position
	gLastX = static_cast<float>(xMousePos);
	gLastY = static_cast<float>(yMousePos);

	// Rotate the camera using the mouse offsets
	if (g_pCamera != nullptr)
	{
		g_pCamera->ProcessMouseMovement(
			xOffset,
			yOffset);
	}
}

/***********************************************************
 * Mouse_Scroll_Callback()
 *
 * Called automatically whenever the mouse wheel is scrolled.
 * The scroll wheel changes the camera movement speed.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(
	GLFWwindow* window,
	double xOffset,
	double yOffset)
{
	// Increase or decrease camera movement speed
	gCameraSpeed +=
		static_cast<float>(yOffset);

	// Keep the speed within a practical range
	if (gCameraSpeed < 1.0f)
	{
		gCameraSpeed = 1.0f;
	}

	if (gCameraSpeed > 20.0f)
	{
		gCameraSpeed = 20.0f;
	}

	// Apply the updated speed to the camera
	if (g_pCamera != nullptr)
	{
		g_pCamera->MovementSpeed = gCameraSpeed;
	}
}

/***********************************************************
 * ProcessKeyboardEvents()
 *
 * Processes keyboard input used to navigate the scene and
 * switch between perspective and orthographic projections.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// Close the window when Escape is pressed
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(
			m_pWindow,
			true);
	}

	// Move the camera forward
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			FORWARD,
			gDeltaTime);
	}

	// Move the camera backward
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			BACKWARD,
			gDeltaTime);
	}

	// Move the camera left
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			LEFT,
			gDeltaTime);
	}

	// Move the camera right
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(
			RIGHT,
			gDeltaTime);
	}

	// Move the camera upward
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->Position.y +=
			g_pCamera->MovementSpeed * gDeltaTime;
	}

	// Move the camera downward
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->Position.y -=
			g_pCamera->MovementSpeed * gDeltaTime;
	}

	// Switch to perspective projection
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_P) == GLFW_PRESS)
	{
		if (!gPKeyPressed)
		{
			bOrthographicProjection = false;
			gPKeyPressed = true;
		}
	}
	else
	{
		gPKeyPressed = false;
	}

	// Switch to orthographic projection
	if (glfwGetKey(
		m_pWindow,
		GLFW_KEY_O) == GLFW_PRESS)
	{
		if (!gOKeyPressed)
		{
			bOrthographicProjection = true;
			gOKeyPressed = true;
		}
	}
	else
	{
		gOKeyPressed = false;
	}
}

/***********************************************************
 * PrepareSceneView()
 *
 * Prepares the camera view and projection matrices before
 * the 3D scene is rendered.
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// Calculate time elapsed since the previous frame
	float currentFrame =
		static_cast<float>(glfwGetTime());

	gDeltaTime =
		currentFrame - gLastFrame;

	gLastFrame =
		currentFrame;

	// Process keyboard input
	ProcessKeyboardEvents();

	// Retrieve the current framebuffer size
	int width = 0;
	int height = 0;

	glfwGetFramebufferSize(
		m_pWindow,
		&width,
		&height);

	// Prevent division by zero when the window is minimized
	if (height == 0)
	{
		height = 1;
	}

	// Update the viewport to match the window
	glViewport(
		0,
		0,
		width,
		height);

	float aspectRatio =
		static_cast<float>(width) /
		static_cast<float>(height);

	if (!bOrthographicProjection)
	{
		// Use the movable camera for perspective mode
		view =
			g_pCamera->GetViewMatrix();

		projection =
			glm::perspective(
				glm::radians(g_pCamera->Zoom),
				aspectRatio,
				0.1f,
				100.0f);
	}
	else
	{
		// Place the orthographic camera directly in front of
		// the scene so the ground plane appears edge-on.
		glm::vec3 orthographicCameraPosition(
			0.0f,
			2.5f,
			12.0f);

		glm::vec3 orthographicTargetPosition(
			0.0f,
			2.5f,
			0.0f);

		glm::vec3 upDirection(
			0.0f,
			1.0f,
			0.0f);

		view =
			glm::lookAt(
				orthographicCameraPosition,
				orthographicTargetPosition,
				upDirection);

		float orthoHeight = 5.0f;
		float orthoWidth =
			orthoHeight * aspectRatio;

		projection =
			glm::ortho(
				-orthoWidth,
				orthoWidth,
				-orthoHeight,
				orthoHeight,
				0.1f,
				100.0f);
	}

	// Pass the view and projection information to the shader
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(
			g_ViewName,
			view);

		m_pShaderManager->setMat4Value(
			g_ProjectionName,
			projection);

		m_pShaderManager->setVec3Value(
			"viewPosition",
			g_pCamera->Position);
	}
}