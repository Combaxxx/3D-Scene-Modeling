///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// Start the loaded texture counter at zero
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);

		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// OpenGL normally expects each image row to be aligned to 4 bytes.
// Setting the unpack alignment to 1 allows RGB textures with widths
// that are not evenly divisible by 4 to load correctly.
		glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
		{
			glTexImage2D(
				GL_TEXTURE_2D,
				0,
				GL_RGB8,
				width,
				height,
				0,
				GL_RGB,
				GL_UNSIGNED_BYTE,
				image);
		}

		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
		{
			glTexImage2D(
				GL_TEXTURE_2D,
				0,
				GL_RGBA8,
				width,
				height,
				0,
				GL_RGBA,
				GL_UNSIGNED_BYTE,
				image);
		}

		else
		{
			std::cout << "Not implemented to handle image with "
				<< colorChannels << " channels" << std::endl;

			stbi_image_free(image);
			return false;
		}

		// restore the normal OpenGL alignment
		glPixelStorei(GL_UNPACK_ALIGNMENT, 4);

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;

	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);

	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));

	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);

		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method defines the materials that are used by the
 *  different objects in the 3D scene. The material values
 *  determine how each object responds to the scene lighting.
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	/****************************************************************/
	/* Define material for the wooden table                         */
	/****************************************************************/

	OBJECT_MATERIAL tableMaterial;

	tableMaterial.diffuseColor = glm::vec3(
		0.45f,
		0.25f,
		0.10f);

	tableMaterial.specularColor = glm::vec3(
		0.30f,
		0.25f,
		0.20f);

	tableMaterial.shininess = 18.0f;

	tableMaterial.tag = "tableMaterial";

	m_objectMaterials.push_back(tableMaterial);


	/****************************************************************/
	/* Define material for the white milk jug                       */
	/****************************************************************/

	OBJECT_MATERIAL milkMaterial;

	milkMaterial.diffuseColor = glm::vec3(
		0.95f,
		0.95f,
		0.95f);

	milkMaterial.specularColor = glm::vec3(
		0.40f,
		0.40f,
		0.40f);

	milkMaterial.shininess = 32.0f;

	milkMaterial.tag = "milkMaterial";

	m_objectMaterials.push_back(milkMaterial);


	/****************************************************************/
	/* Define material for the blue milk jug cap                    */
	/****************************************************************/

	OBJECT_MATERIAL capMaterial;

	capMaterial.diffuseColor = glm::vec3(
		0.10f,
		0.20f,
		0.55f);

	capMaterial.specularColor = glm::vec3(
		0.60f,
		0.60f,
		0.60f);

	capMaterial.shininess = 40.0f;

	capMaterial.tag = "capMaterial";

	m_objectMaterials.push_back(capMaterial);

/****************************************************************/
/* Define material for the gray floor                           */
/****************************************************************/

	OBJECT_MATERIAL floorMaterial;

floorMaterial.diffuseColor = glm::vec3(
	0.48f,
	0.48f,
	0.46f);

floorMaterial.specularColor = glm::vec3(
	0.12f,
	0.12f,
	0.12f);

floorMaterial.shininess = 6.0f;

floorMaterial.tag = "floorMaterial";

m_objectMaterials.push_back(floorMaterial);


	/****************************************************************/
	/* Define material for the off white back wall                  */
	/****************************************************************/

	OBJECT_MATERIAL wallMaterial;

	wallMaterial.diffuseColor = glm::vec3(
		0.82f,
		0.76f,
		0.66f);

	wallMaterial.specularColor = glm::vec3(
		0.08f,
		0.08f,
		0.08f);

	wallMaterial.shininess = 4.0f;

	wallMaterial.tag = "wallMaterial";

	m_objectMaterials.push_back(wallMaterial);

/****************************************************************/
/* Define material for the ceramic bowl                         */
/****************************************************************/

	OBJECT_MATERIAL bowlMaterial;

	bowlMaterial.diffuseColor = glm::vec3(
		0.92f,
		0.92f,
		0.88f);

	bowlMaterial.specularColor = glm::vec3(
		0.45f,
		0.45f,
		0.45f);

	bowlMaterial.shininess = 28.0f;

	bowlMaterial.tag = "bowlMaterial";

	m_objectMaterials.push_back(bowlMaterial);

/****************************************************************/
/* Define material for the cereal box                           */
/****************************************************************/

	OBJECT_MATERIAL cerealMaterial;

	cerealMaterial.diffuseColor = glm::vec3(
		0.05f,
		0.18f,
		0.55f);

	cerealMaterial.specularColor = glm::vec3(
		0.20f,
		0.20f,
		0.25f);

	cerealMaterial.shininess = 12.0f;

	cerealMaterial.tag = "cerealMaterial";

	m_objectMaterials.push_back(cerealMaterial);
}


/***********************************************************
 *  SetupSceneLights()
 *
 *  This method creates and configures the lighting used
 *  throughout the scene. Two point lights are used so that
 *  all objects remain visible and no part of the scene is
 *  left completely in shadow.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// Enable lighting calculations in the shader
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	/****************************************************************/
	/* Main light source                                             */
	/****************************************************************/

	// Main light - above and in front-right of the scene
	m_pShaderManager->setVec3Value(
		"pointLights[0].position",
		5.0f, 9.0f, 7.0f);

	m_pShaderManager->setVec3Value(
		"pointLights[0].diffuse",
		0.80f, 0.85f, 1.00f);

	m_pShaderManager->setVec3Value(
		"pointLights[0].specular",
		0.90f, 0.95f, 1.00f);

	// Specular light creates highlights on reflective materials
	m_pShaderManager->setVec3Value(
		"pointLights[0].specular",
		1.0f, 1.0f, 1.0f);

	// Activate the first point light
	m_pShaderManager->setBoolValue(
		"pointLights[0].bActive",
		true);


	/****************************************************************/
	/* Secondary fill light                                         */
	/****************************************************************/

	// Secondary fill light - above and in front-left
	m_pShaderManager->setVec3Value(
		"pointLights[1].position",
		-5.0f, 9.0f, 5.0f);

	m_pShaderManager->setVec3Value(
		"pointLights[1].diffuse",
		0.32f, 0.36f, 0.45f);

	m_pShaderManager->setVec3Value(
		"pointLights[1].specular",
		0.40f, 0.45f, 0.55f);

	// Add a smaller amount of specular reflection
	m_pShaderManager->setVec3Value(
		"pointLights[1].specular",
		0.45f, 0.45f, 0.45f);

	// Activate the second point light
	m_pShaderManager->setBoolValue(
		"pointLights[1].bActive",
		true);

	/****************************************************************/
	/* Third fill light                                         */
	/****************************************************************/

	// Third fill light - above and in front-left
	m_pShaderManager->setVec3Value(
		"pointLights[1].position",
		5.0f, 3.0f, 7.0f);

	m_pShaderManager->setVec3Value(
		"pointLights[0].diffuse",
		0.80f, 0.85f, 1.00f);

	m_pShaderManager->setVec3Value(
		"pointLights[0].specular",
		0.90f, 0.95f, 1.00f);

	// Specular light creates highlights on reflective materials
	m_pShaderManager->setVec3Value(
		"pointLights[0].specular",
		1.0f, 1.0f, 1.0f);

	// Activate the second point light
	m_pShaderManager->setBoolValue(
		"pointLights[1].bActive",
		true);
}


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	/****************************************************************/
	/* Load textures                                                 */
	/****************************************************************/

	// load the milk texture that will be applied to the jug
	CreateGLTexture("textures/milk.png", "milk");

	// load the blue plastic texture that will be applied to the cap
	CreateGLTexture("textures/cap.png", "cap");

	// Dark wood texture for the table frame and legs
	CreateGLTexture("textures/darkwood.jpg", "darkwood");

	// White marble texture for the center tabletop surface
	CreateGLTexture("textures/whitemarble.jpg", "marble");

	// load the Frosted Flakes texture for the front of the cereal box
	CreateGLTexture("textures/frosted.jpg", "frosted");

	// load the Blue Bowl texture for the bowl
	CreateGLTexture("textures/ceramic.jpg", "ceramic");

	// bind the loaded textures to OpenGL texture slots
	BindGLTextures();


	/****************************************************************/
	/* Define materials and lighting                                 */
	/****************************************************************/

	// define how the different surfaces react to light
	DefineObjectMaterials();

	// configure the lighting for the 3D scene
	SetupSceneLights();


	/****************************************************************/
	/* Load meshes                                                   */
	/****************************************************************/

	// load the plane mesh used for the top surface of the table
	m_basicMeshes->LoadPlaneMesh();

	// load a box mesh used for the table body and legs
	m_basicMeshes->LoadBoxMesh();

	// load the tapered cylinder for the lower jug body
	m_basicMeshes->LoadCylinderMesh();

	// load the sphere for the rounded upper jug body
	m_basicMeshes->LoadSphereMesh();

	// load the cylinder for the neck and cap
	m_basicMeshes->LoadCylinderMesh();

	// load the torus for the handle
	m_basicMeshes->LoadTorusMesh();

	// load the tapered cylinder used for the bowl
	m_basicMeshes->LoadTaperedCylinderMesh();
}


/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;


/****************************************************************/
/* Draw the floor                                                */
/****************************************************************/

// Create a large floor underneath the table
	scaleXYZ = glm::vec3(50.0f, 0.20f, 30.0f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the floor below the bottom of the table legs
	positionXYZ = glm::vec3(0.0f, -8.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("floorMaterial");
	SetShaderColor(0.48f, 0.48f, 0.46f, 1.0f);

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	/* Draw the back wall                                            */
	/****************************************************************/

	// Create a large wall behind the scene
	scaleXYZ = glm::vec3(50.0f, 50.0f, 0.25f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the wall behind the table and jug
	positionXYZ = glm::vec3(0.0f, -1.0f, -8.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("wallMaterial");
	SetShaderColor(0.82f, 0.76f, 0.66f, 1.0f);

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	/* Draw the wooden table top                                    */
	/****************************************************************/

	// Create a thicker rectangular tabletop
	scaleXYZ = glm::vec3(16.0f, 0.65f, 10.0f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Keep the upper surface close to Y = 0 so the jug stays
	// in its current location
	positionXYZ = glm::vec3(0.0f, -0.35f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("tableMaterial");

	// Apply the dark wood texture
	SetShaderTexture("darkwood");

	// Repeat the wood slightly across the large tabletop
	SetTextureUVScale(2.0f, 2.0f);

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	/* Draw the textured surface on top of the table                */
	/****************************************************************/

	scaleXYZ = glm::vec3(7.0f, 1.0f, 4.0f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Slightly above the box so the surfaces do not overlap
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply material to the marble surface
	SetShaderMaterial("tableMaterial");

	// Apply white marble texture
	SetShaderTexture("marble");

	// Do not repeat the marble too much
	SetTextureUVScale(1.0f, 1.0f);

	// Draw the marble center
	m_basicMeshes->DrawPlaneMesh();


	/****************************************************************/
	/* Draw the front left table leg                                */
	/****************************************************************/

	// Make the table legs taller
	scaleXYZ = glm::vec3(0.65f, 8.0f, 0.65f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-6.5f, -4.10f, 3.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("tableMaterial");

	// Apply dark wood texture to table leg
	SetShaderTexture("darkwood");

	// Stretch/repeat texture vertically along the leg
	SetTextureUVScale(1.0f, 2.0f);

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	/* Draw the front right table leg                               */
	/****************************************************************/

	scaleXYZ = glm::vec3(0.65f, 8.0f, 0.65f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(6.5f, -4.10f, 3.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("tableMaterial");

	// Apply dark wood texture to table leg
	SetShaderTexture("darkwood");

	// Stretch/repeat texture vertically along the leg
	SetTextureUVScale(1.0f, 2.0f);

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	/* Draw the rear left table leg                                 */
	/****************************************************************/

	scaleXYZ = glm::vec3(0.65f, 8.0f, 0.65f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-6.5f, -4.10f, -3.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("tableMaterial");

	// Apply dark wood texture to table leg
	SetShaderTexture("darkwood");

	// Stretch/repeat texture vertically along the leg
	SetTextureUVScale(1.0f, 2.0f);

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	/* Draw the rear right table leg                                */
	/****************************************************************/

	scaleXYZ = glm::vec3(0.65f, 8.0f, 0.65f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(6.5f, -4.10f, -3.5f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("tableMaterial");

	// Apply dark wood texture to table leg
	SetShaderTexture("darkwood");

	// Stretch/repeat texture vertically along the leg
	SetTextureUVScale(1.0f, 2.0f);

	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/
	/* Draw the lower body of the milk jug                          */
	/****************************************************************/

	// make the lower body
	scaleXYZ = glm::vec3(1.60f, 2.60f, 1.60f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// place the lower body on the table
	positionXYZ = glm::vec3(3.0f, 0.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply the plastic milk jug material
	SetShaderMaterial("milkMaterial");

	// apply the white milk jug texture
	SetShaderTexture("milk");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();


	/****************************************************************/
	/* Draw the rounded upper body of the milk jug                  */
	/****************************************************************/

	// make the sphere wider and flatter so it looks like shoulders
	scaleXYZ = glm::vec3(1.60f, 1.60f, 1.60f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// overlap the sphere with the top of the lower body
	positionXYZ = glm::vec3(3.0f, 2.50f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply the plastic material to the upper body
	SetShaderMaterial("milkMaterial");

	// apply the same texture so the separate shapes form one cohesive jug
	SetShaderTexture("milk");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawSphereMesh();


	/****************************************************************/
	/* Draw the milk jug neck                                       */
	/****************************************************************/

	// create a centered neck
	scaleXYZ = glm::vec3(0.42f, 0.55f, 0.42f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// center the neck on top of the jug
	positionXYZ = glm::vec3(3.0f, 3.75f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// apply the plastic milk jug material
	SetShaderMaterial("milkMaterial");

	// apply the milk jug texture to the neck
	SetShaderTexture("milk");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();


	/****************************************************************/
	/* Draw the milk jug cap                                        */
	/****************************************************************/

	// make the cap slightly wider than the neck
	scaleXYZ = glm::vec3(0.52f, 0.18f, 0.52f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// center the cap directly above the neck
	positionXYZ = glm::vec3(3.0f, 4.28f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// use the more reflective cap material
	SetShaderMaterial("capMaterial");

	// apply the blue plastic texture to the milk jug cap
	SetShaderTexture("cap");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();


	/****************************************************************/
	/* Draw the milk jug handle                                     */
	/****************************************************************/

	// make the handle longer and more vertical
	scaleXYZ = glm::vec3(0.75f, 1.85f, 0.60f);

	// rotate the torus so the opening faces forward
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// move the handle farther to the left and attach it to the jug
	positionXYZ = glm::vec3(4.45f, 2.75f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// use the same plastic material as the jug
	SetShaderMaterial("milkMaterial");

	// apply the milk jug texture to the handle
	SetShaderTexture("milk");
	SetTextureUVScale(2.0f, 2.0f);

	m_basicMeshes->DrawTorusMesh();

	/****************************************************************/
	/* Draw the main body of the bowl                               */
	/****************************************************************/

	// Use a tapered cylinder to create a bowl that is wide at the
	// top and narrower toward the bottom.
	scaleXYZ = glm::vec3(2.10f, 1.55f, 2.10f);

	XrotationDegrees = 180.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the bowl to the left and slightly in front of the jug
	positionXYZ = glm::vec3(-1.25f, 1.0f, 1.10f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("ceramic");
	SetTextureUVScale(1.0f, 1.0f);


	m_basicMeshes->DrawTaperedCylinderMesh();


	/****************************************************************/
	/* Draw the white rim around the bowl                            */
	/****************************************************************/

	// Keep the torus nearly uniform so it forms a circular rim
	scaleXYZ = glm::vec3(1.95f, 1.0f, 1.95f);

	XrotationDegrees = 180.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Place the rim at the top of the bowl
	positionXYZ = glm::vec3(-1.25f, 0.72f, 1.10f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("marble");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawTaperedCylinderMesh();


	/****************************************************************/
	/* Draw the base of the bowl                                    */
	/****************************************************************/

	// Small ceramic foot underneath the bowl
	scaleXYZ = glm::vec3(1.85f, 0.18f, 1.85f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-1.25f, 0.821f, 1.10f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("bowlMaterial");
	SetShaderColor(0.92f, 0.92f, 0.88f, 1.0f);

	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************/
	/* Draw the cereal box - front panel                            */
	/****************************************************************/

	scaleXYZ = glm::vec3(3.20f, 5.20f, 0.12f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-4.25f, 2.55f, -0.75f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	

	// Apply the Frosted Flakes image to the front panel
	SetShaderTexture("frosted");

	// Keep one copy of the image across the panel
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	/* Draw the cereal box - back panel                             */
	/****************************************************************/

	scaleXYZ = glm::vec3(3.20f, 5.20f, 0.12f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-4.25f, 2.55f, -2.25f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("cerealMaterial");
	SetShaderColor(0.04f, 0.14f, 0.45f, 1.0f);

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	/* Draw the cereal box - left side                              */
	/****************************************************************/

	scaleXYZ = glm::vec3(0.12f, 5.20f, 1.50f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-5.79f, 2.55f, -1.50f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("cerealMaterial");
	SetShaderColor(0.04f, 0.15f, 0.48f, 1.0f);

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	/* Draw the cereal box - right side                             */
	/****************************************************************/

	scaleXYZ = glm::vec3(0.12f, 5.20f, 1.50f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	positionXYZ = glm::vec3(-2.71f, 2.55f, -1.50f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("cerealMaterial");
	SetShaderColor(0.04f, 0.15f, 0.48f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

/****************************************************************/
/* Draw the cereal box - top panel                              */
/****************************************************************/

// Create a thin rectangular panel to close the top of the box
	scaleXYZ = glm::vec3(3.0f, 0.12f, 1.60f);

	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// Position the panel across the top of all four sides
	positionXYZ = glm::vec3(-4.25f, 5.09f, -1.50f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderMaterial("cerealMaterial");

	// Slightly lighter blue for the top of the cereal box
	SetShaderColor(0.07f, 0.22f, 0.60f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	/****************************************************************/
}